<?php

    $db = Database::getInstance();

    $stmtLogin = $db->prepare(
        "select * from users where username = :username "
    );
    $stmtLogin->bindParam(":username", $request["username"]);
    $stmtLogin->execute();

    $user = $stmtLogin->fetch();

    if (!$user)
    {
        header("Location: /auth/login?err=1");
        exit();
    }

    if (password_verify($request['password'], $user['password']))
    {
        $_SESSION['auth']['user'] = $user;
        $_SESSION['auth']['authenticated'] = true;

        header("Location: /");
    }
    else
    {
        header("Location: /auth/login?err=1");
    }
    
    exit();