<?php

    $error = isset($request['err']) ? true : false;

    require __DIR__ . "/../views/login.php";