<?php require __DIR__ . "/layouts/header.php"; ?>

<div class="container center">
    <h1>Fighter</h1>
    <img src="/static/uploads/<?php echo $img['src']; ?>" alt="<?php echo $img['name']; ?>" srcset="">
</div>

<?php require __DIR__ . "/layouts/footer.php"; ?>