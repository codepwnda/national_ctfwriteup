<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col s12">
                <h3>Katalog</h3>
                <p>Saldo anda: $<?php echo e(Auth::user()->balance); ?></p>
                <p>Anda telah membeli <?php echo e($total); ?> catalog</p>
            </div>
            <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="POST" action="/buy/<?php echo e($catalog->slug); ?>">
            <div class="col s4">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title"><?php echo e($catalog->name); ?></span>
                        <?php echo csrf_field(); ?>
                        <img class="responsive-img" src="img/<?php echo e($catalog->src); ?>" alt="" srcset="">
                        <p><?php echo e($catalog->description); ?></p>
                        <p>Harga: $<?php echo e($catalog->price); ?></p>
                        <input type="submit" class="btn" value="Buy">
                    </div>
                </div>
            </div>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p>*WARNING: SEMUA GAMBAR DIATAS BUKAN PUNYA PROBSET YANG BIKIN SOAL INI, TETAPI PUNYA ORANG LAIN YA</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDev\soaljoints19\web\FINAL\waifu-shop\resources\views/dashboard.blade.php ENDPATH**/ ?>