<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col s12">
                <div class="card">
                <div class="card-content">
                    <span class="card-title">Halaman Login</span>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="input-field col s12 m6">
                                <input placeholder="Username" id="username" name="username" type="text" class="validate">
                                <label for="username">Username</label>
                            </div>
                            <div class="input-field col s12 m6">
                                <input placeholder="Password" id="password" name="password" type="password" class="validate">
                                <label for="password">Password</label>
                            </div>
                            <div class="input-field col s12">
                                <input class="btn" type="submit" value="Login">
                            </div>
                            <div class="input-field col s12">
                                <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                    <p><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <p><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                <?php if ($errors->has('auth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('auth'); ?>
                                    <p><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebDev\soaljoints19\web\FINAL\waifu-shop\resources\views/login.blade.php ENDPATH**/ ?>